#if ! (UNITY_DASHBOARD_WIDGET || UNITY_WEBPLAYER || UNITY_WII || UNITY_WIIU || UNITY_NACL || UNITY_FLASH || UNITY_BLACKBERRY) // Disable under unsupported platforms.
/*******************************************************************************
The content of this file includes portions of the proprietary AUDIOKINETIC Wwise
Technology released in source code form as part of the game integration package.
The content of this file may not be used without valid licenses to the
AUDIOKINETIC Wwise Technology.
Note that the use of the game engine is subject to the Unity(R) Terms of
Service at https://unity3d.com/legal/terms-of-service
 
License Usage
 
Licensees holding valid licenses to the AUDIOKINETIC Wwise Technology may use
this file in accordance with the end user license agreement provided with the
software or, alternatively, in accordance with the terms contained
in a written agreement between you and Audiokinetic Inc.
Copyright (c) 2025 Audiokinetic Inc.
*******************************************************************************/

public class AkGameObjEnvironmentData
{
	/// Contains all active environments sorted by default, excludeOthers and priority, even those inside a portal.
	private readonly System.Collections.Generic.List<AkEnvironment> activeEnvironments =
		new System.Collections.Generic.List<AkEnvironment>();

	/// Contains all active environments sorted by priority, even those inside a portal.
	private readonly System.Collections.Generic.List<AkEnvironment> activeEnvironmentsFromPortals =
		new System.Collections.Generic.List<AkEnvironment>();

	/// Contains all active portals.
	private readonly System.Collections.Generic.List<AkEnvironmentPortal> activePortals =
		new System.Collections.Generic.List<AkEnvironmentPortal>();

	private readonly AkAuxSendArray auxSendValues = new AkAuxSendArray();
	private UnityEngine.Vector3 lastPosition = UnityEngine.Vector3.zero;
	private bool hasEnvironmentListChanged = true;
	private bool hasActivePortalListChanged = true;
	private bool hasSentZero = false;

	private void AddHighestPriorityEnvironmentsFromPortals(UnityEngine.Vector3 position)
	{
		for (var i = 0; i < activePortals.Count; i++)
		{
			var portal = activePortals[i];
			if (portal.EnvironmentsShareAuxBus)
			{
				var env = portal.environments[0];
				if (env == null)
					continue;

				var index = activeEnvironmentsFromPortals.BinarySearch(env, AkEnvironment.s_compareByPriority);
				if (index < 0 || index >= AkEnvironment.MAX_NB_ENVIRONMENTS)
					continue;

				var auxBusID = env.data.Id;
				if (!auxSendValues.Contains(auxBusID))
				{
					auxSendValues.Add(auxBusID, 1.0f);
					if (auxSendValues.isFull)
						return;
				}
				continue;
			}

			for (var j = 0; j < AkEnvironmentPortal.MAX_ENVIRONMENTS_PER_PORTAL; j++)
			{
				var env = portal.environments[j];
				if (env == null)
					continue;

				var index = activeEnvironmentsFromPortals.BinarySearch(env, AkEnvironment.s_compareByPriority);
				if (index < 0 || index >= AkEnvironment.MAX_NB_ENVIRONMENTS)
					continue;

				var auxBusID = env.data.Id;
				if (!auxSendValues.Contains(auxBusID))
				{
					auxSendValues.Add(auxBusID, portal.GetAuxSendValueForPosition(position, j));
					if (auxSendValues.isFull)
						return;
				}
			}
		}
	}

	private void AddHighestPriorityEnvironments(UnityEngine.Vector3 position)
	{
		if (!auxSendValues.isFull && auxSendValues.Count() < activeEnvironments.Count)
		{
			for (var i = 0; i < activeEnvironments.Count; i++)
			{
				var env = activeEnvironments[i];
				var auxBusID = env.data.Id;

				if ((!env.isDefault || i == 0) && !auxSendValues.Contains(auxBusID))
				{
					auxSendValues.Add(auxBusID, 1.0f);

					//No other environment can be added after an environment with the excludeOthers flag set to true
					if (env.excludeOthers || auxSendValues.isFull)
						break;
				}
			}
		}
	}

	public void UpdateAuxSend(UnityEngine.GameObject gameObject, UnityEngine.Vector3 position)
	{
		if (!hasEnvironmentListChanged && !hasActivePortalListChanged && lastPosition == position)
			return;

		auxSendValues.Reset();
		AddHighestPriorityEnvironmentsFromPortals(position);
		AddHighestPriorityEnvironments(position);

		bool isSendingZero = auxSendValues.Count() == 0;
		if (!hasSentZero || !isSendingZero)
			auxSendValues.SetValues(gameObject);

		hasSentZero = isSendingZero;
		lastPosition = position;
		hasActivePortalListChanged = false;
		hasEnvironmentListChanged = false;
	}

	private void TryAddEnvironment(AkEnvironment env)
	{
		if (env == null)
			return;

		var index = activeEnvironmentsFromPortals.BinarySearch(env, AkEnvironment.s_compareByPriority);
		if (index >= 0)
			return;

		activeEnvironmentsFromPortals.Insert(~index, env);

		index = activeEnvironments.BinarySearch(env, AkEnvironment.s_compareBySelectionAlgorithm);
		if (index < 0)
			activeEnvironments.Insert(~index, env);

		hasEnvironmentListChanged = true;
	}

	private void RemoveEnvironment(AkEnvironment env)
	{
		activeEnvironmentsFromPortals.Remove(env);
		activeEnvironments.Remove(env);
		hasEnvironmentListChanged = true;
	}

	public void AddAkEnvironment(UnityEngine.Collider environmentCollider, UnityEngine.Collider gameObjectCollider)
	{
		var portal = environmentCollider.GetComponent<AkEnvironmentPortal>();
		if (portal == null)
		{
			var env = environmentCollider.GetComponent<AkEnvironment>();
			TryAddEnvironment(env);
			return;
		}

		activePortals.Add(portal);
		hasActivePortalListChanged = true;

		for (var i = 0; i < AkEnvironmentPortal.MAX_ENVIRONMENTS_PER_PORTAL; i++)
			TryAddEnvironment(portal.environments[i]);
	}

	private bool AkEnvironmentBelongsToActivePortals(AkEnvironment env)
	{
		for (var i = 0; i < activePortals.Count; i++)
		for (var j = 0; j < AkEnvironmentPortal.MAX_ENVIRONMENTS_PER_PORTAL; j++)
		{
			if (env == activePortals[i].environments[j])
				return true;
		}

		return false;
	}

	public void RemoveAkEnvironment(UnityEngine.Collider environmentCollider, UnityEngine.Collider gameObjectCollider)
	{
		var portal = environmentCollider.GetComponent<AkEnvironmentPortal>();
		if (portal != null)
		{
			for (var i = 0; i < AkEnvironmentPortal.MAX_ENVIRONMENTS_PER_PORTAL; i++)
			{
				var env = portal.environments[i];
				if (env != null && !gameObjectCollider.bounds.Intersects(env.Collider.bounds))
					RemoveEnvironment(env);
			}

			activePortals.Remove(portal);
			hasActivePortalListChanged = true;
		}
		else
		{
			var env = environmentCollider.GetComponent<AkEnvironment>();
			if (env != null && !AkEnvironmentBelongsToActivePortals(env))
				RemoveEnvironment(env);
		}
	}
}

#endif // #if ! (UNITY_DASHBOARD_WIDGET || UNITY_WEBPLAYER || UNITY_WII || UNITY_WIIU || UNITY_NACL || UNITY_FLASH || UNITY_BLACKBERRY) // Disable under unsupported platforms.