-- Emscripten Unity premake module
local platform = {}

platform.akName = "Emscripten"
platform.isStatic = true

local function ConvertDependenciesToPostBuildStep(dependencies)
	local addLogs = true

	local newLine = "\r\n"
	local saveRootDirectory = "pushd ."
	local returnToRootDirectory = "popd"
	local ar = "emar"

	local output = ""

	if addLogs then
		output = output .. "echo This script is generated within the premake5.lua file." .. newLine
	end

	output = output .. "echo create $(TARGETDIR)/libAkUnitySoundEngine.a > wrapper.mri" .. newLine
	output = output .. "echo addlib $(TARGETDIR)/libAkUnitySoundEngineStubs.a >> wrapper.mri" .. newLine

	for i,v in ipairs(dependencies) do
		local currentLibPath = wwiseSDKEnv .. "\\Emscripten_st\\%{cfg.buildcfg}\\lib\\lib" .. v .. ".a"
		output = output .. "echo addlib " .. currentLibPath .. " >> wrapper.mri" .. newLine
	end
	output = output .. "echo save >> wrapper.mri" .. newLine
	output = output .. "echo end >> wrapper.mri" .. newLine
	output = output .. "emar -M < wrapper.mri" .. newLine
	output = output .. "del $(subst /,\\,%{cfg.targetdir}/libAkUnitySoundEngineStubs.a)" .. newLine

	-- Also copy the AudioWorklet file to the target directory; this file will be copied to the StreamingAssets directory by the Unity plug-in.
	local jspath = wwiseSDKEnv .. "\\samples\\SoundEngine\\Emscripten\\WwiseAudioWorklet.processor.js"
	output = output .. "copy /Y \"" .. jspath .. "\" $(subst /,\\,%{cfg.targetdir}/../WwiseAudioWorklet.processor.js)"

	return output
end


function platform.GetUnityPlatformName(platformName, cfgplatforms)
    return platformName, cfgplatforms
end

function platform.setupTargetAndLibDir(baseTargetDir)
	targetdir(baseTargetDir .. "WebGL/%{cfg.buildcfg}")
	libdirs(wwiseSDKEnv .. "/Emscripten_st/%{cfg.buildcfg}/lib")
end

function platform.platformSpecificConfiguration()
	targetname("AkUnitySoundEngineStubs")
	
	defines
    {
        "AK_PLATFORM_SPECIFIC_STUBS"
    }

	local function AddPostBuildCommand(useCommunication)
		local depends = SoundEngineInternals("", useCommunication)

		postbuildcommands(ConvertDependenciesToPostBuildStep(depends))
	end

	filter "Debug* or Profile*"
		AddPostBuildCommand(true)
	filter "Release*"
		AddPostBuildCommand(false)


end

return platform
